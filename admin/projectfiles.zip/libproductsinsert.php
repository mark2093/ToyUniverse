<?php  
 $connect = mysqli_connect("localhost", "root", "", "toy_universe1"); 
 echo 
 $_POST 
 if(!empty($_POST))  
 {  
      $output = '';  
      $Title = mysqli_real_escape_string($connect, $_POST["Title"]);  
      $Image = mysqli_real_escape_string($connect, $_POST["Image"]);  
      $Price = mysqli_real_escape_string($connect, $_POST["Price"]);
      $Pro_type = mysqli_real_escape_string($connect, $_POST["Pro_type"]);
      $Category = mysqli_real_escape_string($connect, $_POST["Category"]);  
      $Description = mysqli_real_escape_string($connect, $_POST["Description"]);
      $Main = mysqli_real_escape_string($connect, $_POST["Main"]);
        
      $query = "  
      INSERT INTO lib_products(Title, Image, Price,Pro_type,Category, Description,Main)  
      VALUES('$Title', '$Image', '$Price', '$Pro_type','$Category','$Description','$Main');  
      ";  
      if(mysqli_query($connect, $query))  
      {  
           $output .= '<label class="text-success">Data Inserted</label>';  
           $select_query = "SELECT * FROM lib_products ORDER BY Id DESC";  
           $result = mysqli_query($connect, $select_query);  
           $output .= '  
                <table class="table table-bordered">  
                     <tr>  
                          <th width="70%">Title</th>  
                          <th width="30%">View</th>  
                     </tr>  
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
                          <td>' . $row["Title"] . '</td>  
                          <td><input type="button" name="view" value="view" id="' . $row["Id"] . '" class="btn btn-info btn-xs view_data" /></td>  
                     </tr>  
                ';  
           }  
           $output .= '</table>';  
      }  
      echo $output;  
 }  
 ?>  
