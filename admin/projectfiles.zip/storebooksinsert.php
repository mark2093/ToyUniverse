<?php  
 $connect = mysqli_connect("localhost", "root", "", "toy_universe1"); 
 echo 
 $_POST 
 if(!empty($_POST))  
 {  
      $output = '';  
      $B_title = mysqli_real_escape_string($connect, $_POST["B_title"]);  
      $B_image = mysqli_real_escape_string($connect, $_POST["B_image"]);  
      $B_price = mysqli_real_escape_string($connect, $_POST["B_price"]);  
      $B_category = mysqli_real_escape_string($connect, $_POST["B_category"]);  
      $B_description = mysqli_real_escape_string($connect, $_POST["B_description"]);
      $B_main = mysqli_real_escape_string($connect, $_POST["B_main"]);
        
      $query = "  
      INSERT INTO store_books(B_title, B_image, B_price, B_category, B_description,B_main)  
      VALUES('$B_title', '$B_image', '$B_price', '$B_category','$B_description','$B_main');  
      ";  
      if(mysqli_query($connect, $query))  
      {  
           $output .= '<label class="text-success">Data Inserted</label>';  
           $select_query = "SELECT * FROM store_books ORDER BY B_id DESC";  
           $result = mysqli_query($connect, $select_query);  
           $output .= '  
                <table class="table table-bordered">  
                     <tr>  
                          <th width="70%">B_title</th>  
                          <th width="30%">View</th>  
                     </tr>  
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
                          <td>' . $row["B_title"] . '</td>  
                          <td><input type="button" name="view" value="view" id="' . $row["B_id"] . '" class="btn btn-info btn-xs view_data" /></td>  
                     </tr>  
                ';  
           }  
           $output .= '</table>';  
      }  
      echo $output;  
 }  
 ?>  
