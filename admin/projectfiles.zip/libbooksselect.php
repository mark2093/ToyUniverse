 select.php

 <?php  
 if(isset($_POST["Lb_id"]))  
 {  
      $output = '';  
      $connect = mysqli_connect("localhost", "root", "", "toy_universe1");  
      $query = "SELECT * FROM lib_books WHERE Lb_id = '".$_POST["Lb_id"]."'";  
      $result = mysqli_query($connect, $query);  
      $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td width="30%"><label>Books title</label></td>  
                     <td width="70%">'.$row["Lb_title"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Book image</label></td>  
                     <td width="70%">'.$row["Lb_image"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Books Points</label></td>  
                     <td width="70%">'.$row["Lb_points"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Books category</label></td>  
                     <td width="70%">'.$row["Lb_category"].'</td>  
                </tr>  
               <tr>  
                     <td width="30%"><label>Books description</label></td>  
                     <td width="70%">'.$row["Lb_description"].'</td>  
                </tr>  
               <tr>  
                     <td width="30%"><label>Books main</label></td>  
                     <td width="70%">'.$row["Lb_main"].'</td>  
                </tr>  
               
           ';  
      }  
      $output .= '  
           </table>  
      </div>  
      ';  
      echo $output;  
 }  
 ?>  
