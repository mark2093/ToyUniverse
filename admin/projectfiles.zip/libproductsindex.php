libbooksindex.php

 <?php  
 $connect = mysqli_connect("localhost", "root", "", "toy_universe1");  
 $query = "SELECT * FROM lib_products";  
 $result = mysqli_query($connect, $query);  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>ToyUniverse</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
      </head>  
      <body>  
           <br /><br />  
           <div class="container" style="width:700px;">  
                <h3 align="center">Insert users into the database</h3>  
                <br />  
                <div class="table-responsive">  
                     <div align="right">  
                          <button type="button" name="add" id="add" data-toggle="modal" data-target="#add_data_Modal" class="btn btn-warning">Add</button>  
                     </div>  
                     <br />  
                     <div id="libproducts_table">  
                          <table class="table table-bordered">  
                               <tr>  
                                    <th width="70%">Title</th>  
                                    <th width="30%">View</th>  
                               </tr>  
                               <?php  
                               while($row = mysqli_fetch_array($result))  
                               {  
                               ?>  
                               <tr>  
                                    <td><?php echo $row["Title"]; ?></td>  
                                    <td><input type="button" name="view" value="view" id="<?php echo $row["Id"]; ?>" class="btn btn-info btn-xs view_data" /></td>  
                               </tr>  
                               <?php  
                               }  
                               ?>  
                          </table>  
                     </div>  
                </div>  
           </div>  
      </body>  
 </html>  
 <div id="dataModal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">Library Products Details</h4>  
                </div>  
                <div class="modal-body" id="libproducts_detail">  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  
 <div id="add_data_Modal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">Insert </h4>  
                </div>  
                <div class="modal-body">  
                     <form method="post" id="insert_form">  
                          <label>Enter library product Title</label>  
                          <input type="text" name="Title" id="Title" class="form-control" />  
                          <br />  

                          <label>Enter Library product Image</label>  
                          <input type="text" name="Image" id="Image" class="form-control" />  
                          <br />  
                           
                           <label>Enter Library product price</label>  
                          <input type="text" name="Price" id="Price" class="form-control" />  
                          <br />  

                          <label>Enter Library product type</label>  
                          <input type="text" name="Pro_type" id="Pro_type" class="form-control" />  
                          <br />  


                          <label>Enter Library product category</label>  
                          <input type="text" name="Category" id="Category" class="form-control" />  
                         <br />  

                          <label>Enter Library product description</label>  
                          <input type="text" name="Description" id="Description" class="form-control" />  
                         <br />  
                          
                           <label>Enter Library product main</label>  
                          <input type="text" name="Main" id="Main" class="form-control" />  
                         <br />  
                        
                        
                           <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-success" />  
                     </form>  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  
 <script>  
 $(document).ready(function(){  
      $('#insert_form').on("submit", function(event){  
           event.preventDefault();  
           if($('#Title').val() == "")  
           {  
                alert("Product Title is required");  
           }  
           else if($('#Image').val() == '')  
           {  
                alert("Product Image is required");  
           }  
           else if($('#Price').val() == '')  
           {  
                alert("Price is required");  
           }  
           else if($('#Pro_type').val() == '')  
           {  
                alert("Product type is required");  
           }  
           
           else if($('#Category').val() == '')  
           {  
                alert("Product Category is required");  
           }  
          
           else if($('#Description').val() == '')  
           {  
                alert("Product description is required"); 
          } 
          
           else if($('#Main').val() == '')  
           {  
                alert("Product Main is required");  
           
           else  
           {  
                $.ajax({  
                     url:"insert.php",  
                     method:"POST",  
                     data:$('#insert_form').serialize(),  
                     beforeSend:function(){  
                          $('#insert').val("Inserting");  
                     },  
                     success:function(data){  
                          $('#insert_form')[0].reset();  
                          $('#add_data_Modal').modal('hide');  
                          $('#libproducts_table').html(data);  
                     }  
                });  
           }  
      });  
      $(document).on('click', '.view_data', function(){  
           var Id = $(this).attr("Id");  
           if(Id != '')  
           {  
                $.ajax({  
                     url:"select.php",  
                     method:"POST",  
                     data:{Id:Id},  
                     success:function(data){  
                          $('#libproducts_detail').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      });  
 });  
 </script>  
<!--  -->