 select.php

 <?php  
 if(isset($_POST["B_id"]))  
 {  
      $output = '';  
      $connect = mysqli_connect("localhost", "root", "", "toy_universe1");  
      $query = "SELECT * FROM store_books WHERE B_id = '".$_POST["B_id"]."'";  
      $result = mysqli_query($connect, $query);  
      $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td width="30%"><label>Books title</label></td>  
                     <td width="70%">'.$row["B_title"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Book iamge</label></td>  
                     <td width="70%">'.$row["B_image"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Books Price</label></td>  
                     <td width="70%">'.$row["B_price"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Books category</label></td>  
                     <td width="70%">'.$row["B_category"].'</td>  
                </tr>  
               <tr>  
                     <td width="30%"><label>Books description</label></td>  
                     <td width="70%">'.$row["B_description"].'</td>  
                </tr>  
               <tr>  
                     <td width="30%"><label>Books main</label></td>  
                     <td width="70%">'.$row["B_main"].'</td>  
                </tr>  
               
           ';  
      }  
      $output .= '  
           </table>  
      </div>  
      ';  
      echo $output;  
 }  
 ?>  
