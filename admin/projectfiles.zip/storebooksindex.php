storebooksindex.php

 <?php  
 $connect = mysqli_connect("localhost", "root", "", "toy_universe1");  
 $query = "SELECT * FROM store_books";  
 $result = mysqli_query($connect, $query);  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>ToyUniverse</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
      </head>  
      <body>  
           <br /><br />  
           <div class="container" style="width:700px;">  
                <h3 align="center">Insert users into the database</h3>  
                <br />  
                <div class="table-responsive">  
                     <div align="right">  
                          <button type="button" name="add" id="add" data-toggle="modal" data-target="#add_data_Modal" class="btn btn-warning">Add</button>  
                     </div>  
                     <br />  
                     <div id="storebooks_table">  
                          <table class="table table-bordered">  
                               <tr>  
                                    <th width="70%">B_title</th>  
                                    <th width="30%">View</th>  
                               </tr>  
                               <?php  
                               while($row = mysqli_fetch_array($result))  
                               {  
                               ?>  
                               <tr>  
                                    <td><?php echo $row["B_title"]; ?></td>  
                                    <td><input type="button" name="view" value="view" id="<?php echo $row["B_id"]; ?>" class="btn btn-info btn-xs view_data" /></td>  
                               </tr>  
                               <?php  
                               }  
                               ?>  
                          </table>  
                     </div>  
                </div>  
           </div>  
      </body>  
 </html>  
 <div id="dataModal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">Store books Details</h4>  
                </div>  
                <div class="modal-body" id="storebooks_detail">  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  
 <div id="add_data_Modal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">Insert </h4>  
                </div>  
                <div class="modal-body">  
                     <form method="post" id="insert_form">  
                          <label>Enter Store Book Title</label>  
                          <input type="text" name="B_title" id="B_title" class="form-control" />  
                          <br />  

                          <label>Enter Store books Image</label>  
                          <input type="text" name="B_image" id="B_image" class="form-control" />  
                          <br />  
                           
                           <label>Enter Store books price</label>  
                          <input type="text" name="B_price" id="B_price" class="form-control" />  
                          <br />  

                          <label>Enter Store books category</label>  
                          <input type="text" name="B_category" id="B_category" class="form-control" />  
                         <br />  

                          <label>Enter Store books description</label>  
                          <input type="text" name="B_description" id="B_description" class="form-control" />  
                         <br />  
                          
                           <label>Enter Store books main</label>  
                          <input type="text" name="B_main" id="B_main" class="form-control" />  
                         <br />  
                        
                        
                           <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-success" />  
                     </form>  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  
 <script>  
 $(document).ready(function(){  
      $('#insert_form').on("submit", function(event){  
           event.preventDefault();  
           if($('#B_title').val() == "")  
           {  
                alert("Book Title is required");  
           }  
           else if($('#B_image').val() == '')  
           {  
                alert("Image is required");  
           }  
           else if($('#B_price').val() == '')  
           {  
                alert("Price is required");  
           }  
           else if($('#B_category').val() == '')  
           {  
                alert("Category is required");  
           }  
          
           else if($('#B_description').val() == '')  
           {  
                alert("description is required"); 
          } 
          
           else if($('#B_main').val() == '')  
           {  
                alert("Main is required");  
           
           else  
           {  
                $.ajax({  
                     url:"insert.php",  
                     method:"POST",  
                     data:$('#insert_form').serialize(),  
                     beforeSend:function(){  
                          $('#insert').val("Inserting");  
                     },  
                     success:function(data){  
                          $('#insert_form')[0].reset();  
                          $('#add_data_Modal').modal('hide');  
                          $('#storebooks_table').html(data);  
                     }  
                });  
           }  
      });  
      $(document).on('click', '.view_data', function(){  
           var B_id = $(this).attr("B_id");  
           if(B_id != '')  
           {  
                $.ajax({  
                     url:"select.php",  
                     method:"POST",  
                     data:{Lb_id:Lb_id},  
                     success:function(data){  
                          $('#storebooks_detail').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      });  
 });  
 </script>  
<!--  -->