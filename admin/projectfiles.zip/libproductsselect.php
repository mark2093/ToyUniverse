select.php

 <?php  
 if(isset($_POST["Id"]))  
 {  
      $output = '';  
      $connect = mysqli_connect("localhost", "root", "", "toy_universe1");  
      $query = "SELECT * FROM lib_products WHERE Id = '".$_POST["Id"]."'";  
      $result = mysqli_query($connect, $query);  
      $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td width="30%"><label>Product title</label></td>  
                     <td width="70%">'.$row["Title"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Product image</label></td>  
                     <td width="70%">'.$row["Image"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Product Price</label></td>  
                     <td width="70%">'.$row["Price"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Product type</label></td>  
                     <td width="70%">'.$row["Pro_type"].'</td>  
                </tr>  
                
                <tr>  
                     <td width="30%"><label>Product Category</label></td>  
                     <td width="70%">'.$row["Category"].'</td>  
                </tr>  
               <tr>  
                     <td width="30%"><label>Products Description</label></td>  
                     <td width="70%">'.$row["Description"].'</td>  
                </tr>  
               <tr>  
                     <td width="30%"><label>Product main</label></td>  
                     <td width="70%">'.$row["Main"].'</td>  
                </tr>  
               
           ';  
      }  
      $output .= '  
           </table>  
      </div>  
      ';  
      echo $output;  
 }  
 ?>  
