select.php

 <?php  
 if(isset($_POST["St_id"]))  
 {  
      $output = '';  
      $connect = mysqli_connect("localhost", "root", "", "toy_universe1");  
      $query = "SELECT * FROM store_toys WHERE St_id = '".$_POST["St_id"]."'";  
      $result = mysqli_query($connect, $query);  
      $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td width="30%"><label>Toys title</label></td>  
                     <td width="70%">'.$row["St_title"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Toys iamge</label></td>  
                     <td width="70%">'.$row["St_image"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Toys Price</label></td>  
                     <td width="70%">'.$row["St_price"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Toys category</label></td>  
                     <td width="70%">'.$row["St_category"].'</td>  
                </tr>  
               <tr>  
                     <td width="30%"><label>Toys description</label></td>  
                     <td width="70%">'.$row["St_description"].'</td>  
                </tr>  
               <tr>  
                     <td width="30%"><label>Toys main</label></td>  
                     <td width="70%">'.$row["St_main"].'</td>  
                </tr>  
               
           ';  
      }  
      $output .= '  
           </table>  
      </div>  
      ';  
      echo $output;  
 }  
 ?>  
