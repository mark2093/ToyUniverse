<?php  
 $connect = mysqli_connect("localhost", "root", "", "toy_universe1"); 
 echo 
 $_POST 
 if(!empty($_POST))  
 {  
      $output = '';  
      $Lb_title = mysqli_real_escape_string($connect, $_POST["Lb_title"]);  
      $Lb_image = mysqli_real_escape_string($connect, $_POST["Lb_image"]);  
      $Lb_points = mysqli_real_escape_string($connect, $_POST["Lb_points"]);  
      $Lb_category = mysqli_real_escape_string($connect, $_POST["Lb_category"]);  
      $Lb_description = mysqli_real_escape_string($connect, $_POST["Lb_description"]);
      $Lb_main = mysqli_real_escape_string($connect, $_POST["Lb_main"]);
        
      $query = "  
      INSERT INTO lib_books(Lb_title, Lb_image, Lb_points, Lb_category, Lb_description,Lb_main)  
      VALUES('$Lb_title', '$Lb_image', '$Lb_points', '$Lb_category','$Lb_description','$Lb_main');  
      ";  
      if(mysqli_query($connect, $query))  
      {  
           $output .= '<label class="text-success">Data Inserted</label>';  
           $select_query = "SELECT * FROM lib_books ORDER BY Lb_id DESC";  
           $result = mysqli_query($connect, $select_query);  
           $output .= '  
                <table class="table table-bordered">  
                     <tr>  
                          <th width="70%">lb_title</th>  
                          <th width="30%">View</th>  
                     </tr>  
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
                          <td>' . $row["Lb_title"] . '</td>  
                          <td><input type="button" name="view" value="view" id="' . $row["Lb_id"] . '" class="btn btn-info btn-xs view_data" /></td>  
                     </tr>  
                ';  
           }  
           $output .= '</table>';  
      }  
      echo $output;  
 }  
 ?>  
