<?php  
 $connect = mysqli_connect("localhost", "root", "", "toy_universe1"); 
 echo 
 $_POST 
 if(!empty($_POST))  
 {  
      $output = '';  
      $St_title = mysqli_real_escape_string($connect, $_POST["St_title"]);  
      $St_image = mysqli_real_escape_string($connect, $_POST["St_image"]);  
      $St_price = mysqli_real_escape_string($connect, $_POST["St_price"]);  
      $St_category = mysqli_real_escape_string($connect, $_POST["St_category"]);  
      $St_description = mysqli_real_escape_string($connect, $_POST["St_description"]);
      $St_main = mysqli_real_escape_string($connect, $_POST["St_main"]);
        
      $query = "  
      INSERT INTO Store_toys(St_title, St_image, St_price, St_category, St_description,St_main)  
      VALUES('$St_title', '$St_image', '$St_price', '$St_category','$St_description','$St_main');  
      ";  
      if(mysqli_query($connect, $query))  
      {  
           $output .= '<label class="text-success">Data Inserted</label>';  
           $select_query = "SELECT * FROM store_toys ORDER BY St_id DESC";  
           $result = mysqli_query($connect, $select_query);  
           $output .= '  
                <table class="table table-bordered">  
                     <tr>  
                          <th width="70%">St_title</th>  
                          <th width="30%">View</th>  
                     </tr>  
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
                          <td>' . $row["St_title"] . '</td>  
                          <td><input type="button" name="view" value="view" id="' . $row["St_id"] . '" class="btn btn-info btn-xs view_data" /></td>  
                     </tr>  
                ';  
           }  
           $output .= '</table>';  
      }  
      echo $output;  
 }  
 ?>  
